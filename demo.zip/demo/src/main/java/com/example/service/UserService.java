package com.example.service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.example.model.User;

@Service
public class UserService {
    private final Map<UUID, User> userStore = new HashMap<>();

    public User createUser(String name, String email) {
        User user = new User(name, email);
        userStore.put(user.getId(), user);
        return user;
    }

    public User getUser(UUID id) {
        User user = userStore.get(id);
        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }
        return user;
    }
}